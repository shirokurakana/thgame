<!--
if(document.images){
	var Img_file = new Array();
	Img_file[0] = new Image(); Img_file[0].src = "image/shortcut1.gif";
	Img_file[1] = new Image(); Img_file[1].src = "image/shortcut2.gif";
}
function ChageImage(id,ImgName){
	if(document.images){
		if(Img_file[ImgName]){
			document.images[id].src = Img_file[ImgName].src;
		}else{
			document.images[id].src = ImgName;
		}
	}
}
// -->
